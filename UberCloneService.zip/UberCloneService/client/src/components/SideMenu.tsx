import { Link, useLocation } from "wouter";
import { 
  User, 
  History, 
  CreditCard, 
  Gift, 
  Settings, 
  HelpCircle, 
  LogOut 
} from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface SideMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SideMenu({ isOpen, onClose }: SideMenuProps) {
  const { user, logout } = useAuth();
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  
  const handleLogout = async () => {
    try {
      await apiRequest("POST", "/api/auth/logout", {});
      logout();
      toast({
        title: "Logged out successfully",
      });
    } catch (error) {
      toast({
        title: "Error logging out",
        description: error instanceof Error ? error.message : "Something went wrong",
        variant: "destructive",
      });
    }
  };
  
  const handleNavigate = (path: string) => {
    setLocation(path);
    onClose();
  };
  
  return (
    <div
      id="side-menu"
      className={`fixed inset-y-0 left-0 bg-white w-4/5 max-w-xs shadow-xl z-50 transform transition-transform duration-300 ease-in-out ${
        isOpen ? "translate-x-0" : "-translate-x-full"
      }`}
    >
      <div className="p-5 border-b border-neutral-200">
        <div className="flex items-center">
          <div className="w-12 h-12 bg-neutral-200 rounded-full overflow-hidden mr-3">
            <img 
              src={user?.profileImage || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde"}
              alt="User profile" 
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <h3 className="font-medium">{user?.fullName || "User"}</h3>
            <p className="text-sm text-neutral-500">
              {user?.rating ? `${user.rating.toFixed(2)} ★` : "New user"}
            </p>
          </div>
        </div>
      </div>
      
      <div className="py-2">
        <button 
          className="flex items-center w-full px-5 py-3 hover:bg-neutral-100 text-left"
          onClick={() => handleNavigate("/profile")}
        >
          <User className="mr-3 h-5 w-5" />
          <span>Profile</span>
        </button>
        
        <button 
          className="flex items-center w-full px-5 py-3 hover:bg-neutral-100 text-left"
          onClick={() => handleNavigate("/history")}
        >
          <History className="mr-3 h-5 w-5" />
          <span>Ride history</span>
        </button>
        
        <button className="flex items-center w-full px-5 py-3 hover:bg-neutral-100 text-left">
          <CreditCard className="mr-3 h-5 w-5" />
          <span>Payment methods</span>
        </button>
        
        <button className="flex items-center w-full px-5 py-3 hover:bg-neutral-100 text-left">
          <Gift className="mr-3 h-5 w-5" />
          <span>Promotions</span>
        </button>
        
        <button className="flex items-center w-full px-5 py-3 hover:bg-neutral-100 text-left">
          <Settings className="mr-3 h-5 w-5" />
          <span>Settings</span>
        </button>
        
        <button className="flex items-center w-full px-5 py-3 hover:bg-neutral-100 text-left">
          <HelpCircle className="mr-3 h-5 w-5" />
          <span>Help</span>
        </button>
      </div>
      
      <div className="absolute bottom-0 left-0 right-0 p-5 border-t border-neutral-200">
        <button 
          className="flex items-center text-red-500"
          onClick={handleLogout}
        >
          <LogOut className="mr-3 h-5 w-5" />
          <span>Log out</span>
        </button>
      </div>
    </div>
  );
}
