import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import Layout from "../components/Layout";
import Header from "../components/Header";
import LocationSearch from "../components/LocationSearch";
import RideSelection from "../components/RideSelection";
import RideConfirmed from "../components/RideConfirmed";
import RateDriver from "../components/RateDriver";
import { useRide } from "../contexts/RideContext";
import { useAuth } from "../contexts/AuthContext";
import DriverView from "../components/DriverView";
import { useGeolocation } from "../hooks/useGeolocation";
import { useToast } from "@/hooks/use-toast";

interface HomeProps {
  onMenuClick: () => void;
}

export default function Home({ onMenuClick }: HomeProps) {
  const { user } = useAuth();
  const { state, setPickupLocation, setActiveRide, resetRide } = useRide();
  const { position, error: geoError } = useGeolocation();
  const { toast } = useToast();
  
  const [bottomSheetExpanded, setBottomSheetExpanded] = useState(false);
  const [rideStatus, setRideStatus] = useState<"selecting" | "requested" | "confirmed" | "completed" | "rating">("selecting");
  
  // Get active rides on load
  const { data: activeRides, isLoading } = useQuery({
    queryKey: ['/api/rides/active'],
    refetchInterval: 5000,
  });
  
  // Check for active ride on component mount
  useEffect(() => {
    if (activeRides?.length && activeRides[0].status !== "completed") {
      setActiveRide(activeRides[0].id);
      setRideStatus("confirmed");
    }
  }, [activeRides]);
  
  // Set initial pickup location based on geolocation
  useEffect(() => {
    if (position && !state.pickupLocation) {
      const { latitude, longitude } = position.coords;
      // We just set the coordinates here, the actual address will be set by the Google Maps geocoder
      setPickupLocation({ lat: latitude, lng: longitude }, "Current Location");
      
      // Geocode the location to get the address
      const geocoder = new google.maps.Geocoder();
      geocoder.geocode(
        { location: { lat: latitude, lng: longitude } },
        (results, status) => {
          if (status === "OK" && results && results.length > 0) {
            setPickupLocation(
              { lat: latitude, lng: longitude },
              results[0].formatted_address
            );
          }
        }
      );
    }
  }, [position, state.pickupLocation]);
  
  // Show geolocation error
  useEffect(() => {
    if (geoError) {
      toast({
        title: "Location error",
        description: "Could not get your current location. Please enter it manually.",
        variant: "destructive",
      });
    }
  }, [geoError]);
  
  const toggleBottomSheet = () => {
    setBottomSheetExpanded(!bottomSheetExpanded);
  };
  
  const handleLocationSelect = () => {
    if (state.pickupLocation && state.dropoffLocation) {
      setBottomSheetExpanded(true);
    }
  };
  
  const handleRideRequest = () => {
    setRideStatus("requested");
    
    // Simulate finding a driver after 2 seconds
    setTimeout(() => {
      setRideStatus("confirmed");
    }, 3000);
  };
  
  const handleRideCancel = () => {
    resetRide();
    setRideStatus("selecting");
  };
  
  const handleRideComplete = () => {
    setRideStatus("rating");
  };
  
  const handleRatingComplete = () => {
    resetRide();
    setRideStatus("selecting");
    setBottomSheetExpanded(false);
  };
  
  // Show driver view if user is a driver
  if (user?.isDriver) {
    return <DriverView onMenuClick={onMenuClick} />;
  }
  
  // Loading state
  if (isLoading) {
    return (
      <div className="h-screen w-full flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }
  
  return (
    <Layout>
      {/* Header */}
      <Header onMenuClick={onMenuClick} />
      
      {/* Location Search */}
      {rideStatus === "selecting" && (
        <LocationSearch onLocationSelect={handleLocationSelect} />
      )}
      
      {/* Ride Selection */}
      {rideStatus === "selecting" && state.pickupLocation && state.dropoffLocation && (
        <RideSelection 
          onRideRequest={handleRideRequest} 
          expanded={bottomSheetExpanded}
          onToggleExpand={toggleBottomSheet}
        />
      )}
      
      {/* Finding Driver Loading State */}
      {rideStatus === "requested" && (
        <div className="fixed inset-0 bg-white/80 flex items-center justify-center z-50">
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mb-4"></div>
            <p className="text-lg font-medium">Finding your ride...</p>
          </div>
        </div>
      )}
      
      {/* Ride Confirmed View */}
      {rideStatus === "confirmed" && state.activeRideId && (
        <RideConfirmed 
          rideId={state.activeRideId} 
          onCancel={handleRideCancel}
          onComplete={handleRideComplete}
        />
      )}
      
      {/* Rate Driver View */}
      {rideStatus === "rating" && state.activeRideId && (
        <RateDriver 
          rideId={state.activeRideId}
          onClose={handleRatingComplete}
        />
      )}
    </Layout>
  );
}
