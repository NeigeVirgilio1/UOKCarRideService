import { RIDE_TYPES } from "@shared/schema";

// Base fare in dollars per kilometer
const BASE_FARE_PER_KM = 1.5;

// Minimum fare for any ride
const MIN_FARE = 5.0;

// Time cost in dollars per minute
const TIME_COST_PER_MINUTE = 0.2;

// Base booking fee
const BOOKING_FEE = 2.5;

// Calculate price based on distance and ride type
export const calculatePrice = (distanceInKm: number, rideType: string): number => {
  // Get multiplier for the ride type
  const typeMultiplier = RIDE_TYPES[rideType as keyof typeof RIDE_TYPES]?.multiplier || 1.0;
  
  // Calculate distance-based fare
  let fare = distanceInKm * BASE_FARE_PER_KM * typeMultiplier;
  
  // Add booking fee
  fare += BOOKING_FEE;
  
  // Ensure minimum fare
  fare = Math.max(fare, MIN_FARE);
  
  // Round to 2 decimal places
  return Math.round(fare * 100) / 100;
};

// Format price for display
export const formatPrice = (price: number): string => {
  return `$${price.toFixed(2)}`;
};

// Calculate estimated time of arrival (ETA)
export const getETA = (durationInMinutes: number): string => {
  if (!durationInMinutes) return "15 min"; // Default
  
  // Round to nearest minute
  const minutes = Math.round(durationInMinutes);
  
  if (minutes < 60) {
    return `${minutes} min`;
  } else {
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    
    if (remainingMinutes === 0) {
      return `${hours} hr`;
    } else {
      return `${hours} hr ${remainingMinutes} min`;
    }
  }
};

// Calculate surge pricing based on demand
export const calculateSurgePricing = (
  basePrice: number, 
  demandFactor: number // 1.0 is normal, >1.0 is high demand
): number => {
  // Cap the surge multiplier at 3.0x
  const surgeMultiplier = Math.min(demandFactor, 3.0);
  
  return basePrice * surgeMultiplier;
};

// Estimate wait time based on driver availability
export const estimateWaitTime = (
  distanceToNearestDriver: number, // in km
  trafficCondition: 'light' | 'moderate' | 'heavy' = 'moderate'
): number => {
  // Average speed in km/min under different traffic conditions
  const avgSpeed = {
    light: 0.7,     // 42 km/h
    moderate: 0.5,  // 30 km/h
    heavy: 0.3      // 18 km/h
  };
  
  // Calculate time in minutes
  const timeInMinutes = distanceToNearestDriver / avgSpeed[trafficCondition];
  
  // Add pickup buffer time
  const bufferTime = 2;
  
  // Round up and ensure minimum wait time
  return Math.max(Math.ceil(timeInMinutes + bufferTime), 3);
};

// Random driver data for mocking
export const getRandomDrivers = (count: number = 3) => {
  const driverNames = [
    "Michael Johnson",
    "Sarah Wilson",
    "David Martinez",
    "Emma Thompson",
    "James Anderson",
    "Olivia Garcia",
    "Robert Smith",
    "Sophia Lee",
    "William Brown",
    "Isabella Taylor"
  ];
  
  const driverProfiles = [
    "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d",
    "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2",
    "https://images.unsplash.com/photo-1568602471122-7832951cc4c5",
    "https://images.unsplash.com/photo-1544005313-94ddf0286df2",
    "https://images.unsplash.com/photo-1500648767791-00dcc994a43e"
  ];
  
  const vehicleMakes = ["Toyota", "Honda", "Tesla", "BMW", "Ford"];
  const vehicleModels = ["Camry", "Civic", "Model 3", "X5", "Fusion"];
  const vehicleColors = ["Black", "White", "Silver", "Blue", "Red"];
  
  const drivers = [];
  
  for (let i = 0; i < count; i++) {
    const nameIndex = Math.floor(Math.random() * driverNames.length);
    const profileIndex = Math.floor(Math.random() * driverProfiles.length);
    const makeIndex = Math.floor(Math.random() * vehicleMakes.length);
    const modelIndex = Math.floor(Math.random() * vehicleModels.length);
    const colorIndex = Math.floor(Math.random() * vehicleColors.length);
    
    drivers.push({
      id: i + 1,
      name: driverNames[nameIndex],
      profile: driverProfiles[profileIndex],
      rating: (4 + Math.random()).toFixed(2),
      vehicle: {
        make: vehicleMakes[makeIndex],
        model: vehicleModels[modelIndex],
        color: vehicleColors[colorIndex],
        licensePlate: `${String.fromCharCode(65 + Math.floor(Math.random() * 26))}${String.fromCharCode(65 + Math.floor(Math.random() * 26))}${String.fromCharCode(65 + Math.floor(Math.random() * 26))} ${Math.floor(Math.random() * 10)}${Math.floor(Math.random() * 10)}${Math.floor(Math.random() * 10)}`
      },
      eta: 2 + Math.floor(Math.random() * 8)
    });
  }
  
  return drivers;
};
