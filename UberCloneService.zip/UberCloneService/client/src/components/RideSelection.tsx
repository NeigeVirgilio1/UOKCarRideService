import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { RIDE_TYPES } from "@shared/schema";
import { useRide } from "../contexts/RideContext";
import { calculatePrice, formatPrice, getETA } from "../lib/rideUtils";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "../lib/queryClient";

interface RideSelectionProps {
  onRideRequest: () => void;
  expanded: boolean;
  onToggleExpand: () => void;
}

export default function RideSelection({ onRideRequest, expanded, onToggleExpand }: RideSelectionProps) {
  const { state, selectRideType } = useRide();
  const { toast } = useToast();
  const [isRequesting, setIsRequesting] = useState(false);
  
  // Get payment methods
  const { data: paymentMethods } = useQuery({
    queryKey: ['/api/payment-methods'],
    enabled: expanded,
  });
  
  const defaultPaymentMethod = paymentMethods?.find(pm => pm.isDefault) || paymentMethods?.[0];
  
  // Driver availability (simulated)
  const driverAvailability = {
    economy: { available: true, time: 5 },
    comfort: { available: true, time: 8 },
    premium: { available: true, time: 3 },
  };
  
  const handleRideRequest = async () => {
    if (!state.pickupLocation || !state.dropoffLocation || !state.selectedRideType) {
      toast({
        title: "Cannot request ride",
        description: "Please select pickup and dropoff locations",
        variant: "destructive",
      });
      return;
    }
    
    setIsRequesting(true);
    
    try {
      // Calculate ride details
      const price = calculatePrice(state.distance, state.selectedRideType);
      const duration = state.duration || 15;
      
      // Create ride request
      await apiRequest("POST", "/api/rides", {
        pickupLocation: state.pickupLocationName,
        dropoffLocation: state.dropoffLocationName,
        pickupLatitude: state.pickupLocation.lat,
        pickupLongitude: state.pickupLocation.lng,
        dropoffLatitude: state.dropoffLocation.lat,
        dropoffLongitude: state.dropoffLocation.lng,
        rideType: state.selectedRideType,
        estimatedPrice: price,
        estimatedDistance: state.distance,
        estimatedDuration: duration,
        requestedAt: new Date(),
      });
      
      onRideRequest();
    } catch (error) {
      toast({
        title: "Error requesting ride",
        description: error instanceof Error ? error.message : "Something went wrong",
        variant: "destructive",
      });
    } finally {
      setIsRequesting(false);
    }
  };
  
  if (!state.pickupLocation || !state.dropoffLocation) {
    return null;
  }
  
  const bottomSheetClass = expanded
    ? "bottom-sheet-expanded"
    : "bottom-sheet-collapsed";
  
  return (
    <div className={`absolute bottom-0 left-0 right-0 bg-white rounded-t-2xl shadow-2xl z-20 bottom-sheet ${bottomSheetClass}`}>
      <div className="flex justify-center p-2" onClick={onToggleExpand}>
        <div className="w-12 h-1 bg-neutral-300 rounded-full"></div>
      </div>
      
      <div className="px-4 pt-2 pb-4">
        <h2 className="text-lg font-semibold mb-4">Choose a ride</h2>
        
        <div className="space-y-4">
          {Object.entries(RIDE_TYPES).map(([type, details]) => {
            const isSelected = state.selectedRideType === type;
            const price = formatPrice(calculatePrice(state.distance, type));
            const eta = getETA(state.duration);
            
            return (
              <div 
                key={type}
                className={`flex items-center p-3 border rounded-lg cursor-pointer hover:border-primary transition-colors ${
                  isSelected ? "border-primary bg-primary/5" : "border-neutral-200"
                }`}
                onClick={() => selectRideType(type)}
              >
                <div className="flex-shrink-0 w-14 h-14 mr-3">
                  <img src={details.image} alt={`${details.name} car`} className="w-full h-full object-contain" />
                </div>
                <div className="flex-1">
                  <h3 className="font-medium">{details.name}</h3>
                  <p className="text-sm text-neutral-500">
                    {details.seats} seats • {driverAvailability[type].time} min away
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-medium">{price}</p>
                  <p className="text-sm text-neutral-500">{eta}</p>
                </div>
              </div>
            );
          })}
        </div>
        
        {/* Payment Method */}
        {defaultPaymentMethod && (
          <div className="mt-4 mb-2 flex justify-between items-center">
            <div className="flex items-center">
              <i className="ri-bank-card-line text-lg mr-2"></i>
              <span>
                {defaultPaymentMethod.type.charAt(0).toUpperCase() + defaultPaymentMethod.type.slice(1)} 
                •••• {defaultPaymentMethod.lastFour}
              </span>
            </div>
            <button className="text-primary text-sm">Change</button>
          </div>
        )}
        
        {/* Request Button */}
        <Button 
          className="w-full bg-primary text-white font-semibold py-3 rounded-lg mt-2 hover:bg-primary/90"
          onClick={handleRideRequest}
          disabled={isRequesting}
        >
          {isRequesting ? (
            <div className="flex items-center justify-center">
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
              Finding your ride...
            </div>
          ) : (
            `Request ${state.selectedRideType ? RIDE_TYPES[state.selectedRideType].name : 'Ride'}`
          )}
        </Button>
      </div>
    </div>
  );
}
