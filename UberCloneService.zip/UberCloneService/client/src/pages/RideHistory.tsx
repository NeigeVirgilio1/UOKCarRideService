import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { ArrowLeft, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { RIDE_TYPES, Ride } from "@shared/schema";
import { formatPrice } from "../lib/rideUtils";
import { format } from "date-fns";

export default function RideHistory() {
  const [_, setLocation] = useLocation();
  
  // Get ride history
  const { data: rides, isLoading } = useQuery({
    queryKey: ['/api/rides'],
  });
  
  // Group rides by date
  const groupRidesByDate = (rides: Ride[]) => {
    const groups: Record<string, Ride[]> = {};
    
    rides?.forEach(ride => {
      const date = new Date(ride.requestedAt);
      const dateKey = format(date, 'yyyy-MM-dd');
      
      if (!groups[dateKey]) {
        groups[dateKey] = [];
      }
      
      groups[dateKey].push(ride);
    });
    
    return groups;
  };
  
  const groupedRides = rides ? groupRidesByDate(rides) : {};
  const sortedDates = Object.keys(groupedRides).sort((a, b) => new Date(b).getTime() - new Date(a).getTime());
  
  // Format date for display
  const formatDateHeading = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    if (date.toDateString() === today.toDateString()) {
      return "Today";
    } else if (date.toDateString() === yesterday.toDateString()) {
      return "Yesterday";
    } else {
      return format(date, 'MMMM d, yyyy');
    }
  };
  
  // Get ride status display text
  const getRideStatusDisplay = (status: string) => {
    switch(status) {
      case "completed":
        return "Completed";
      case "cancelled":
        return "Cancelled";
      case "in_progress":
        return "In Progress";
      case "accepted":
        return "Accepted";
      case "requested":
        return "Requested";
      default:
        return status.charAt(0).toUpperCase() + status.slice(1);
    }
  };
  
  // Get status color class
  const getStatusColorClass = (status: string) => {
    switch(status) {
      case "completed":
        return "bg-green-500/10 text-green-500";
      case "cancelled":
        return "bg-red-500/10 text-red-500";
      case "in_progress":
        return "bg-primary/10 text-primary";
      case "accepted":
        return "bg-primary/10 text-primary";
      case "requested":
        return "bg-yellow-500/10 text-yellow-500";
      default:
        return "bg-neutral-500/10 text-neutral-500";
    }
  };
  
  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Header */}
      <div className="bg-white px-4 py-3 flex items-center border-b">
        <Button 
          variant="ghost" 
          size="icon" 
          className="mr-2"
          onClick={() => setLocation("/")}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-lg font-semibold">Your Rides</h1>
      </div>
      
      {/* Ride History List */}
      <div className="container max-w-md mx-auto py-4 px-4">
        {isLoading ? (
          <div className="flex justify-center py-10">
            <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : rides?.length ? (
          <div className="space-y-6">
            {sortedDates.map(dateKey => (
              <div key={dateKey}>
                <h2 className="text-sm font-medium text-neutral-500 mb-2">
                  {formatDateHeading(dateKey)}
                </h2>
                <div className="space-y-3">
                  {groupedRides[dateKey].map(ride => {
                    const rideType = RIDE_TYPES[ride.rideType as keyof typeof RIDE_TYPES];
                    return (
                      <Card key={ride.id} className="overflow-hidden">
                        <CardContent className="p-0">
                          <div className="p-4">
                            <div className="flex justify-between items-start mb-3">
                              <div>
                                <h3 className="font-medium">{rideType?.name || ride.rideType}</h3>
                                <p className="text-sm text-neutral-500">
                                  {format(new Date(ride.requestedAt), 'h:mm a')}
                                </p>
                              </div>
                              <div className="flex flex-col items-end">
                                <span className="font-medium">{formatPrice(ride.estimatedPrice)}</span>
                                <span className={`text-xs px-2 py-1 rounded-full mt-1 ${getStatusColorClass(ride.status)}`}>
                                  {getRideStatusDisplay(ride.status)}
                                </span>
                              </div>
                            </div>
                            
                            <div className="flex items-start space-x-3">
                              <div className="flex flex-col items-center pt-1">
                                <div className="w-3 h-3 rounded-full bg-primary"></div>
                                <div className="w-0.5 h-8 bg-neutral-300 my-1"></div>
                                <div className="w-3 h-3 rounded-full bg-green-500"></div>
                              </div>
                              <div className="flex-1">
                                <div className="mb-2">
                                  <p className="text-sm font-medium">From</p>
                                  <p className="text-sm text-neutral-500 truncate">{ride.pickupLocation}</p>
                                </div>
                                <div>
                                  <p className="text-sm font-medium">To</p>
                                  <p className="text-sm text-neutral-500 truncate">{ride.dropoffLocation}</p>
                                </div>
                              </div>
                            </div>
                            
                            {ride.driverRating && (
                              <div className="flex items-center mt-3 pt-3 border-t border-neutral-100">
                                <Star className="h-4 w-4 text-yellow-400 mr-1" fill="currentColor" />
                                <span className="text-sm">You rated {ride.driverRating}/5</span>
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-10">
            <div className="bg-neutral-100 rounded-full p-4 mb-3">
              <svg className="w-10 h-10 text-neutral-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 9l-7 7-7-7" />
              </svg>
            </div>
            <h2 className="text-lg font-medium text-neutral-700">No rides yet</h2>
            <p className="text-sm text-neutral-500 mt-1">Book your first ride to see your history</p>
            <Button 
              className="mt-4"
              onClick={() => setLocation("/")}
            >
              Book a ride
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
