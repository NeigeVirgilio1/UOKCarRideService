// Promise-based wrapper for Google Maps Directions service
export const getRoute = (
  origin: { lat: number; lng: number },
  destination: { lat: number; lng: number }
): Promise<google.maps.DirectionsResult> => {
  return new Promise((resolve, reject) => {
    const directionsService = new google.maps.DirectionsService();
    
    directionsService.route(
      {
        origin: new google.maps.LatLng(origin.lat, origin.lng),
        destination: new google.maps.LatLng(destination.lat, destination.lng),
        travelMode: google.maps.TravelMode.DRIVING,
      },
      (result, status) => {
        if (status === google.maps.DirectionsStatus.OK) {
          resolve(result!);
        } else {
          reject(new Error(`Directions request failed: ${status}`));
        }
      }
    );
  });
};

// Calculate distance between two points (Haversine formula)
export const calculateDistance = (
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number => {
  const R = 6371; // Radius of the earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c; // Distance in km
  return d;
};

const deg2rad = (deg: number): number => {
  return deg * (Math.PI / 180);
};

// Get the center point of an array of coordinates
export const getCenterOfCoordinates = (
  coordinates: Array<{ lat: number; lng: number }>
): { lat: number; lng: number } => {
  if (!coordinates.length) {
    return { lat: 0, lng: 0 };
  }
  
  let x = 0;
  let y = 0;
  let z = 0;
  
  coordinates.forEach(coord => {
    const lat = (coord.lat * Math.PI) / 180;
    const lng = (coord.lng * Math.PI) / 180;
    
    x += Math.cos(lat) * Math.cos(lng);
    y += Math.cos(lat) * Math.sin(lng);
    z += Math.sin(lat);
  });
  
  const total = coordinates.length;
  x = x / total;
  y = y / total;
  z = z / total;
  
  const centralLongitude = Math.atan2(y, x);
  const centralSquareRoot = Math.sqrt(x * x + y * y);
  const centralLatitude = Math.atan2(z, centralSquareRoot);
  
  return {
    lat: (centralLatitude * 180) / Math.PI,
    lng: (centralLongitude * 180) / Math.PI
  };
};

// Format a distance in km to a human-readable string
export const formatDistance = (distanceInKm: number): string => {
  if (distanceInKm < 1) {
    return `${Math.round(distanceInKm * 1000)} m`;
  }
  return `${distanceInKm.toFixed(1)} km`;
};

// Calculate the bounds that include all coordinates
export const calculateBounds = (
  coordinates: Array<{ lat: number; lng: number }>
): google.maps.LatLngBounds => {
  const bounds = new google.maps.LatLngBounds();
  
  coordinates.forEach(coord => {
    bounds.extend(new google.maps.LatLng(coord.lat, coord.lng));
  });
  
  return bounds;
};

// Get a map zoom level that fits all coordinates within the viewport
export const getZoomLevelForBounds = (
  bounds: google.maps.LatLngBounds,
  mapWidth: number,
  mapHeight: number
): number => {
  const GLOBE_WIDTH = 256; // Width of the globe in pixels at zoom level 0
  const ZOOM_MAX = 21;
  
  const ne = bounds.getNorthEast();
  const sw = bounds.getSouthWest();
  
  const latFraction = (ne.lat() - sw.lat()) / 180;
  const lngFraction = (ne.lng() - sw.lng()) / 360;
  
  const latZoom = Math.floor(Math.log(mapHeight / GLOBE_WIDTH / latFraction) / Math.LN2);
  const lngZoom = Math.floor(Math.log(mapWidth / GLOBE_WIDTH / lngFraction) / Math.LN2);
  
  return Math.min(latZoom, lngZoom, ZOOM_MAX);
};
