import { ReactNode } from "react";
import Map from "./Map";
import { useRide } from "../contexts/RideContext";

interface LayoutProps {
  children: ReactNode;
  mapProps?: {
    pickupLocation?: { lat: number; lng: number } | null;
    dropoffLocation?: { lat: number; lng: number } | null;
    route?: google.maps.DirectionsResult | null;
  };
}

export default function Layout({ children, mapProps }: LayoutProps) {
  const { state } = useRide();
  
  const defaultMapProps = {
    pickupLocation: state.pickupLocation,
    dropoffLocation: state.dropoffLocation,
    route: state.route
  };
  
  const mergedMapProps = { ...defaultMapProps, ...mapProps };
  
  return (
    <div className="relative h-screen w-full">
      {/* Map container */}
      <div className="absolute inset-0 z-0">
        <Map 
          pickupLocation={mergedMapProps.pickupLocation} 
          dropoffLocation={mergedMapProps.dropoffLocation} 
          route={mergedMapProps.route}
        />
      </div>
      
      {/* Content */}
      <div className="relative z-10 h-full">
        {children}
      </div>
    </div>
  );
}
