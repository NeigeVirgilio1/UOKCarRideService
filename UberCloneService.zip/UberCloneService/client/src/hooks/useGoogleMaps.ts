import { useState, useEffect } from "react";

interface UseGoogleMapsReturn {
  isLoaded: boolean;
  loadError: Error | null;
}

export const useGoogleMaps = (): UseGoogleMapsReturn => {
  const [isLoaded, setIsLoaded] = useState<boolean>(false);
  const [loadError, setLoadError] = useState<Error | null>(null);

  useEffect(() => {
    // Check if Google Maps API is already loaded
    if (window.google && window.google.maps) {
      setIsLoaded(true);
      return;
    }

    // Check if script is already in the process of loading
    const existingScript = document.getElementById("google-maps-script");
    if (existingScript) {
      // If the script is already loading, wait for it to complete
      const handleScriptLoad = () => {
        setIsLoaded(true);
      };

      const handleScriptError = () => {
        setLoadError(new Error("Google Maps failed to load"));
      };

      existingScript.addEventListener("load", handleScriptLoad);
      existingScript.addEventListener("error", handleScriptError);

      return () => {
        existingScript.removeEventListener("load", handleScriptLoad);
        existingScript.removeEventListener("error", handleScriptError);
      };
    } else {
      // If Google Maps is not loading yet, check if it's available in the HTML
      const checkIfLoaded = setInterval(() => {
        if (window.google && window.google.maps) {
          clearInterval(checkIfLoaded);
          setIsLoaded(true);
        }
      }, 100);

      // Set a timeout to clear the interval if the script doesn't load
      const timeout = setTimeout(() => {
        clearInterval(checkIfLoaded);
        if (!window.google || !window.google.maps) {
          setLoadError(new Error("Google Maps failed to load"));
        }
      }, 10000); // 10 seconds timeout

      return () => {
        clearInterval(checkIfLoaded);
        clearTimeout(timeout);
      };
    }
  }, []);

  return { isLoaded, loadError };
};
