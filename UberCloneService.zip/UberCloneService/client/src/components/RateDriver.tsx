import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Textarea } from "@/components/ui/textarea";

interface RateDriverProps {
  rideId: number;
  onClose: () => void;
}

export default function RateDriver({ rideId, onClose }: RateDriverProps) {
  const [rating, setRating] = useState<number | null>(null);
  const [comment, setComment] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  
  // Get ride details
  const { data: ride } = useQuery({
    queryKey: [`/api/rides/${rideId}`],
  });
  
  // Get driver details
  const { data: driver } = useQuery({
    queryKey: [`/api/users/${ride?.driverId}`],
    enabled: !!ride?.driverId,
  });
  
  const handleRatingClick = (selectedRating: number) => {
    setRating(selectedRating);
  };
  
  const handleSubmit = async () => {
    if (rating === null) {
      toast({
        title: "Please select a rating",
        description: "Tap on the stars to rate your driver",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    try {
      await apiRequest("PATCH", `/api/rides/${rideId}`, {
        driverRating: rating,
        driverComment: comment,
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/rides'] });
      
      toast({
        title: "Thank you for your rating!",
        description: "Your feedback helps improve our service",
      });
      
      onClose();
    } catch (error) {
      toast({
        title: "Error submitting rating",
        description: error instanceof Error ? error.message : "Something went wrong",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleSkip = () => {
    onClose();
  };
  
  return (
    <div className="fixed inset-0 bg-white z-50">
      <div className="flex flex-col h-full">
        <div className="p-4 border-b border-neutral-200">
          <button onClick={onClose}>
            <X className="h-6 w-6" />
          </button>
        </div>
        
        <div className="flex-1 flex flex-col items-center justify-center p-6">
          <img 
            src={driver?.profileImage || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d"}
            alt="Driver" 
            className="w-20 h-20 rounded-full object-cover mb-4"
          />
          <h2 className="text-xl font-semibold mb-1">How was your ride with {driver?.fullName?.split(' ')[0] || "your driver"}?</h2>
          <p className="text-neutral-500 mb-6">Your feedback helps improve driving quality</p>
          
          <div className="flex space-x-3 mb-8">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                className="text-2xl"
                onClick={() => handleRatingClick(star)}
              >
                {star <= (rating || 0) ? (
                  <svg className="w-8 h-8 text-yellow-400 fill-current" viewBox="0 0 20 20">
                    <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                  </svg>
                ) : (
                  <svg className="w-8 h-8 text-neutral-300 hover:text-yellow-400 fill-current" viewBox="0 0 20 20">
                    <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                  </svg>
                )}
              </button>
            ))}
          </div>
          
          <div className="w-full mb-6">
            <Textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="w-full p-3 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              rows={3}
              placeholder="Leave a comment (optional)"
            />
          </div>
          
          <div className="w-full">
            <Button 
              className="w-full bg-primary text-white font-semibold py-3 rounded-lg disabled:bg-neutral-300 disabled:cursor-not-allowed"
              disabled={rating === null || isSubmitting}
              onClick={handleSubmit}
            >
              {isSubmitting ? (
                <div className="flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Submitting...
                </div>
              ) : (
                "Submit"
              )}
            </Button>
            <Button 
              variant="ghost"
              className="w-full text-neutral-500 font-medium py-3 mt-2"
              onClick={handleSkip}
              disabled={isSubmitting}
            >
              Skip
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
