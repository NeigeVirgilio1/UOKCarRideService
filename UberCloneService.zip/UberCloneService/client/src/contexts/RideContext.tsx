import { createContext, useContext, useReducer, ReactNode } from "react";

interface RideState {
  pickupLocation: { lat: number; lng: number } | null;
  dropoffLocation: { lat: number; lng: number } | null;
  pickupLocationName: string | null;
  dropoffLocationName: string | null;
  selectedRideType: string | null;
  route: google.maps.DirectionsResult | null;
  distance: number; // in km
  duration: number; // in minutes
  activeRideId: number | null;
}

type RideAction =
  | { type: "SET_PICKUP_LOCATION"; location: { lat: number; lng: number }; name: string }
  | { type: "SET_DROPOFF_LOCATION"; location: { lat: number; lng: number }; name: string }
  | { type: "SET_RIDE_TYPE"; rideType: string }
  | { type: "SET_ROUTE"; route: google.maps.DirectionsResult; distance: number; duration: number }
  | { type: "SET_ACTIVE_RIDE"; rideId: number | null }
  | { type: "RESET_RIDE" };

interface RideContextType {
  state: RideState;
  setPickupLocation: (location: { lat: number; lng: number }, name: string) => void;
  setDropoffLocation: (location: { lat: number; lng: number }, name: string) => void;
  selectRideType: (rideType: string) => void;
  setRoute: (route: google.maps.DirectionsResult, distance: number, duration: number) => void;
  setActiveRide: (rideId: number | null) => void;
  resetRide: () => void;
}

const initialState: RideState = {
  pickupLocation: null,
  dropoffLocation: null,
  pickupLocationName: null,
  dropoffLocationName: null,
  selectedRideType: "premium", // Default to premium ride
  route: null,
  distance: 0,
  duration: 0,
  activeRideId: null,
};

const rideReducer = (state: RideState, action: RideAction): RideState => {
  switch (action.type) {
    case "SET_PICKUP_LOCATION":
      return {
        ...state,
        pickupLocation: action.location,
        pickupLocationName: action.name,
      };
    case "SET_DROPOFF_LOCATION":
      return {
        ...state,
        dropoffLocation: action.location,
        dropoffLocationName: action.name,
      };
    case "SET_RIDE_TYPE":
      return {
        ...state,
        selectedRideType: action.rideType,
      };
    case "SET_ROUTE":
      return {
        ...state,
        route: action.route,
        distance: action.distance,
        duration: action.duration,
      };
    case "SET_ACTIVE_RIDE":
      return {
        ...state,
        activeRideId: action.rideId,
      };
    case "RESET_RIDE":
      return {
        ...initialState,
        // Keep user's pickup location for convenience
        pickupLocation: state.pickupLocation,
        pickupLocationName: state.pickupLocationName,
      };
    default:
      return state;
  }
};

const RideContext = createContext<RideContextType | undefined>(undefined);

export function RideProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(rideReducer, initialState);

  const setPickupLocation = (location: { lat: number; lng: number }, name: string) => {
    dispatch({ type: "SET_PICKUP_LOCATION", location, name });
  };

  const setDropoffLocation = (location: { lat: number; lng: number }, name: string) => {
    dispatch({ type: "SET_DROPOFF_LOCATION", location, name });
  };

  const selectRideType = (rideType: string) => {
    dispatch({ type: "SET_RIDE_TYPE", rideType });
  };

  const setRoute = (route: google.maps.DirectionsResult, distance: number, duration: number) => {
    dispatch({ type: "SET_ROUTE", route, distance, duration });
  };
  
  const setActiveRide = (rideId: number | null) => {
    dispatch({ type: "SET_ACTIVE_RIDE", rideId });
  };

  const resetRide = () => {
    dispatch({ type: "RESET_RIDE" });
  };

  return (
    <RideContext.Provider
      value={{
        state,
        setPickupLocation,
        setDropoffLocation,
        selectRideType,
        setRoute,
        setActiveRide,
        resetRide,
      }}
    >
      {children}
    </RideContext.Provider>
  );
}

export function useRide() {
  const context = useContext(RideContext);
  if (context === undefined) {
    throw new Error("useRide must be used within a RideProvider");
  }
  return context;
}
