import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertUserSchema, insertRideSchema, insertPaymentMethodSchema, insertVehicleSchema } from "@shared/schema";

// Add session type extension
declare module "express-session" {
  interface SessionData {
    userId: number;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User with this email already exists" });
      }
      
      const user = await storage.createUser(userData);
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      // Set session
      if (req.session) {
        req.session.userId = user.id;
      }
      
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid user data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Error creating user" });
      }
    }
  });
  
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
      }
      
      const user = await storage.getUserByEmail(email);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      // Set session
      if (req.session) {
        req.session.userId = user.id;
      }
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Error logging in" });
    }
  });
  
  app.post("/api/auth/logout", (req: Request, res: Response) => {
    req.session?.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Error logging out" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });
  
  app.get("/api/auth/me", async (req: Request, res: Response) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Error fetching user" });
    }
  });
  
  // Middleware to check if user is authenticated
  const isAuthenticated = async (req: Request, res: Response, next: Function) => {
    if (!req.session?.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    next();
  };
  
  // User routes
  app.get("/api/users/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = Number(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Only return limited info for other users
      if (req.session?.userId !== userId) {
        return res.json({
          id: user.id,
          fullName: user.fullName,
          profileImage: user.profileImage,
          rating: user.rating,
          isDriver: user.isDriver
        });
      }
      
      // Remove password from response for own profile
      const { password, ...userWithoutPassword } = user;
      
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Error fetching user" });
    }
  });
  
  app.patch("/api/users/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = Number(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Only allow updating own profile
      if (req.session?.userId !== userId) {
        return res.status(403).json({ message: "Not authorized to update this user" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't allow updating certain fields
      const { id, password, ...updateData } = req.body;
      
      const updatedUser = await storage.updateUser(userId, updateData);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = updatedUser;
      
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Error updating user" });
    }
  });
  
  // Ride routes
  app.post("/api/rides", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const rideData = insertRideSchema.parse({
        ...req.body,
        riderId: req.session?.userId
      });
      
      const ride = await storage.createRide(rideData);
      
      res.status(201).json(ride);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid ride data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Error creating ride" });
      }
    }
  });
  
  app.get("/api/rides", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = req.session?.userId!;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      let rides;
      if (user.isDriver) {
        rides = await storage.getDriverRides(userId);
      } else {
        rides = await storage.getUserRides(userId);
      }
      
      res.json(rides);
    } catch (error) {
      res.status(500).json({ message: "Error fetching rides" });
    }
  });
  
  app.get("/api/rides/active", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = req.session?.userId!;
      const activeRides = await storage.getActiveRidesByUser(userId);
      
      res.json(activeRides);
    } catch (error) {
      res.status(500).json({ message: "Error fetching active rides" });
    }
  });
  
  app.get("/api/rides/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const rideId = Number(req.params.id);
      if (isNaN(rideId)) {
        return res.status(400).json({ message: "Invalid ride ID" });
      }
      
      const ride = await storage.getRide(rideId);
      if (!ride) {
        return res.status(404).json({ message: "Ride not found" });
      }
      
      // Only allow access to rides the user is involved in
      const userId = req.session?.userId!;
      if (ride.riderId !== userId && ride.driverId !== userId) {
        return res.status(403).json({ message: "Not authorized to access this ride" });
      }
      
      res.json(ride);
    } catch (error) {
      res.status(500).json({ message: "Error fetching ride" });
    }
  });
  
  app.patch("/api/rides/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const rideId = Number(req.params.id);
      if (isNaN(rideId)) {
        return res.status(400).json({ message: "Invalid ride ID" });
      }
      
      const ride = await storage.getRide(rideId);
      if (!ride) {
        return res.status(404).json({ message: "Ride not found" });
      }
      
      // Check authorization based on update type
      const userId = req.session?.userId!;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Handle different types of updates based on user type and ride status
      const updateData: Partial<typeof ride> = {};
      
      // Driver accepting a ride
      if (user.isDriver && ride.status === "requested" && req.body.status === "accepted") {
        updateData.driverId = userId;
        updateData.status = "accepted";
      }
      // Driver starting a ride
      else if (user.isDriver && ride.status === "accepted" && req.body.status === "in_progress" && ride.driverId === userId) {
        updateData.status = "in_progress";
      }
      // Driver completing a ride
      else if (user.isDriver && ride.status === "in_progress" && req.body.status === "completed" && ride.driverId === userId) {
        updateData.status = "completed";
        updateData.completedAt = new Date();
        updateData.actualPrice = ride.estimatedPrice; // In a real app, this would be calculated
      }
      // Rider rating a driver
      else if (!user.isDriver && ride.status === "completed" && ride.riderId === userId && req.body.driverRating) {
        updateData.driverRating = Number(req.body.driverRating);
        updateData.driverComment = req.body.driverComment;
        
        // Update driver rating
        if (ride.driverId) {
          const driver = await storage.getUser(ride.driverId);
          if (driver) {
            const newRatingCount = driver.ratingCount + 1;
            const newRating = ((driver.rating * driver.ratingCount) + updateData.driverRating!) / newRatingCount;
            await storage.updateUser(ride.driverId, {
              rating: newRating,
              ratingCount: newRatingCount
            });
          }
        }
      }
      // Driver rating a rider
      else if (user.isDriver && ride.status === "completed" && ride.driverId === userId && req.body.riderRating) {
        updateData.riderRating = Number(req.body.riderRating);
        updateData.riderComment = req.body.riderComment;
        
        // Update rider rating
        const rider = await storage.getUser(ride.riderId);
        if (rider) {
          const newRatingCount = rider.ratingCount + 1;
          const newRating = ((rider.rating * rider.ratingCount) + updateData.riderRating!) / newRatingCount;
          await storage.updateUser(ride.riderId, {
            rating: newRating,
            ratingCount: newRatingCount
          });
        }
      }
      // Rider cancelling a ride
      else if (!user.isDriver && (ride.status === "requested" || ride.status === "accepted") && ride.riderId === userId && req.body.status === "cancelled") {
        updateData.status = "cancelled";
      }
      else {
        return res.status(403).json({ message: "Not authorized to perform this update" });
      }
      
      const updatedRide = await storage.updateRide(rideId, updateData);
      if (!updatedRide) {
        return res.status(404).json({ message: "Ride not found" });
      }
      
      res.json(updatedRide);
    } catch (error) {
      res.status(500).json({ message: "Error updating ride" });
    }
  });
  
  // Driver routes
  app.get("/api/driver/requests", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = req.session?.userId!;
      const user = await storage.getUser(userId);
      
      if (!user || !user.isDriver) {
        return res.status(403).json({ message: "Not authorized as a driver" });
      }
      
      // Get nearby ride requests
      // In a real app, the driver's location would be provided
      const nearbyRequests = await storage.getNearbyRideRequests(0, 0, 10);
      
      res.json(nearbyRequests);
    } catch (error) {
      res.status(500).json({ message: "Error fetching ride requests" });
    }
  });
  
  // Payment method routes
  app.get("/api/payment-methods", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = req.session?.userId!;
      const paymentMethods = await storage.getUserPaymentMethods(userId);
      
      res.json(paymentMethods);
    } catch (error) {
      res.status(500).json({ message: "Error fetching payment methods" });
    }
  });
  
  app.post("/api/payment-methods", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const paymentMethodData = insertPaymentMethodSchema.parse({
        ...req.body,
        userId: req.session?.userId
      });
      
      const paymentMethod = await storage.createPaymentMethod(paymentMethodData);
      
      res.status(201).json(paymentMethod);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid payment method data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Error creating payment method" });
      }
    }
  });
  
  // Vehicle routes
  app.get("/api/vehicles", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = req.session?.userId!;
      const user = await storage.getUser(userId);
      
      if (!user || !user.isDriver) {
        return res.status(403).json({ message: "Not authorized as a driver" });
      }
      
      const vehicles = await storage.getDriverVehicles(userId);
      
      res.json(vehicles);
    } catch (error) {
      res.status(500).json({ message: "Error fetching vehicles" });
    }
  });
  
  app.post("/api/vehicles", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = req.session?.userId!;
      const user = await storage.getUser(userId);
      
      if (!user || !user.isDriver) {
        return res.status(403).json({ message: "Not authorized as a driver" });
      }
      
      const vehicleData = insertVehicleSchema.parse({
        ...req.body,
        driverId: userId
      });
      
      const vehicle = await storage.createVehicle(vehicleData);
      
      res.status(201).json(vehicle);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid vehicle data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Error creating vehicle" });
      }
    }
  });
  
  const httpServer = createServer(app);
  
  return httpServer;
}
