import { useEffect, useState, useRef } from "react";
import { Input } from "@/components/ui/input";
import { useRide } from "../contexts/RideContext";
import { useGoogleMaps } from "../hooks/useGoogleMaps";
import { getRoute } from "../lib/mapUtils";

interface LocationSearchProps {
  onLocationSelect: () => void;
}

export default function LocationSearch({ onLocationSelect }: LocationSearchProps) {
  const { isLoaded } = useGoogleMaps();
  const { state, setPickupLocation, setDropoffLocation, setRoute } = useRide();
  const pickupInputRef = useRef<HTMLInputElement>(null);
  const dropoffInputRef = useRef<HTMLInputElement>(null);
  const [pickupAutocomplete, setPickupAutocomplete] = useState<google.maps.places.Autocomplete | null>(null);
  const [dropoffAutocomplete, setDropoffAutocomplete] = useState<google.maps.places.Autocomplete | null>(null);
  
  // Initialize autocomplete when Google Maps is loaded
  useEffect(() => {
    if (!isLoaded || !pickupInputRef.current || !dropoffInputRef.current) return;
    
    const pickupOptions = {
      fields: ["geometry", "formatted_address", "name"],
      componentRestrictions: { country: "us" },
    };
    
    const dropoffOptions = {
      fields: ["geometry", "formatted_address", "name"],
      componentRestrictions: { country: "us" },
    };
    
    const pickupInstance = new google.maps.places.Autocomplete(pickupInputRef.current, pickupOptions);
    const dropoffInstance = new google.maps.places.Autocomplete(dropoffInputRef.current, dropoffOptions);
    
    setPickupAutocomplete(pickupInstance);
    setDropoffAutocomplete(dropoffInstance);
    
    // Setup listeners
    pickupInstance.addListener("place_changed", () => {
      const place = pickupInstance.getPlace();
      if (place.geometry?.location) {
        const location = {
          lat: place.geometry.location.lat(),
          lng: place.geometry.location.lng(),
        };
        const name = place.formatted_address || place.name || "";
        setPickupLocation(location, name);
        
        // If dropoff is set, calculate route
        if (state.dropoffLocation) {
          calculateRoute(location, state.dropoffLocation);
        }
        
        onLocationSelect();
      }
    });
    
    dropoffInstance.addListener("place_changed", () => {
      const place = dropoffInstance.getPlace();
      if (place.geometry?.location) {
        const location = {
          lat: place.geometry.location.lat(),
          lng: place.geometry.location.lng(),
        };
        const name = place.formatted_address || place.name || "";
        setDropoffLocation(location, name);
        
        // If pickup is set, calculate route
        if (state.pickupLocation) {
          calculateRoute(state.pickupLocation, location);
        }
        
        onLocationSelect();
      }
    });
    
    return () => {
      // Clean up listeners
      google.maps.event.clearInstanceListeners(pickupInstance);
      google.maps.event.clearInstanceListeners(dropoffInstance);
    };
  }, [isLoaded, state.pickupLocation, state.dropoffLocation]);
  
  // Calculate and set route
  const calculateRoute = async (origin: { lat: number; lng: number }, destination: { lat: number; lng: number }) => {
    try {
      const result = await getRoute(origin, destination);
      if (result) {
        setRoute(
          result,
          result.routes[0].legs[0].distance.value / 1000, // Convert to km
          result.routes[0].legs[0].duration.value / 60 // Convert to minutes
        );
      }
    } catch (error) {
      console.error("Error calculating route:", error);
    }
  };
  
  return (
    <div className="absolute top-16 left-4 right-4 z-10">
      <div className="bg-white rounded-lg shadow-lg p-4">
        <div className="flex items-center mb-3">
          <div className="flex flex-col items-center mr-3">
            <div className="w-3 h-3 rounded-full bg-primary"></div>
            <div className="w-0.5 h-10 bg-neutral-300 my-1"></div>
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
          </div>
          <div className="flex-1 space-y-3">
            <div>
              <Input 
                ref={pickupInputRef}
                type="text" 
                className="w-full px-3 py-2 text-sm border-b border-neutral-200 focus:outline-none focus:border-primary"
                placeholder="Current location"
                defaultValue={state.pickupLocationName || ""}
              />
            </div>
            <div>
              <Input 
                ref={dropoffInputRef}
                type="text" 
                className="w-full px-3 py-2 text-sm border-b border-neutral-200 focus:outline-none focus:border-primary"
                placeholder="Where to?"
                defaultValue={state.dropoffLocationName || ""}
              />
            </div>
          </div>
        </div>
        <div className="flex space-x-2">
          <button className="flex items-center justify-center px-3 py-1.5 text-xs border border-neutral-200 rounded-full">
            <span className="mr-1">⏱️</span>
            Now
          </button>
          <button className="flex items-center justify-center px-3 py-1.5 text-xs border border-neutral-200 rounded-full">
            <span className="mr-1">⭐</span>
            Saved
          </button>
        </div>
      </div>
    </div>
  );
}
