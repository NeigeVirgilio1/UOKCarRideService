import { Menu, Bell, User } from "lucide-react";
import { Button } from "@/components/ui/button";

interface HeaderProps {
  onMenuClick: () => void;
  onProfileClick?: () => void;
  onNotificationsClick?: () => void;
}

export default function Header({ onMenuClick, onProfileClick, onNotificationsClick }: HeaderProps) {
  return (
    <div className="absolute top-0 left-0 right-0 z-10 px-4 py-3 flex justify-between items-center">
      <Button 
        id="menu-button" 
        variant="outline" 
        size="icon" 
        className="bg-white p-2 rounded-full shadow-md"
        onClick={onMenuClick}
      >
        <Menu className="h-5 w-5" />
      </Button>
      
      <div className="flex items-center space-x-2">
        <Button 
          variant="outline" 
          size="icon" 
          className="bg-white p-2 rounded-full shadow-md relative"
          onClick={onNotificationsClick}
        >
          <Bell className="h-5 w-5" />
          <span className="absolute top-0 right-0 h-2 w-2 bg-primary rounded-full"></span>
        </Button>
        
        <Button 
          variant="outline" 
          size="icon" 
          className="bg-white p-2 rounded-full shadow-md"
          onClick={onProfileClick}
        >
          <User className="h-5 w-5" />
        </Button>
      </div>
    </div>
  );
}
