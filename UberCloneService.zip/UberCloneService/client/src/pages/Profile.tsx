import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ArrowLeft, Camera, Star, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "../contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

// Profile update form schema
const profileSchema = z.object({
  fullName: z.string().min(2, "Full name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  phoneNumber: z.string().min(10, "Phone number must be at least 10 characters"),
});

type ProfileFormValues = z.infer<typeof profileSchema>;

export default function Profile() {
  const [_, setLocation] = useLocation();
  const { user, updateUser } = useAuth();
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Get payment methods
  const { data: paymentMethods } = useQuery({
    queryKey: ['/api/payment-methods'],
  });
  
  // Get ride history for stats
  const { data: rides } = useQuery({
    queryKey: ['/api/rides'],
  });
  
  // Vehicle data for drivers
  const { data: vehicles } = useQuery({
    queryKey: ['/api/vehicles'],
    enabled: user?.isDriver === true,
  });
  
  // Form setup
  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      fullName: user?.fullName || "",
      email: user?.email || "",
      phoneNumber: user?.phoneNumber || "",
    },
  });
  
  const handleSubmit = async (values: ProfileFormValues) => {
    if (!user) return;
    
    setIsSubmitting(true);
    try {
      const response = await apiRequest("PATCH", `/api/users/${user.id}`, values);
      const updatedUser = await response.json();
      
      updateUser(updatedUser);
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      
      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully",
      });
      
      setIsEditing(false);
    } catch (error) {
      toast({
        title: "Update failed",
        description: error instanceof Error ? error.message : "Could not update profile",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Stats calculations
  const totalRides = rides?.length || 0;
  const completedRides = rides?.filter(ride => ride.status === "completed").length || 0;
  
  // Get default payment method
  const defaultPaymentMethod = paymentMethods?.find(pm => pm.isDefault) || paymentMethods?.[0];
  
  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Header */}
      <div className="bg-white px-4 py-3 flex items-center border-b">
        <Button 
          variant="ghost" 
          size="icon" 
          className="mr-2"
          onClick={() => isEditing ? setIsEditing(false) : setLocation("/")}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-lg font-semibold">{isEditing ? "Edit Profile" : "Profile"}</h1>
        {!isEditing && (
          <Button 
            variant="ghost" 
            className="ml-auto"
            onClick={() => setIsEditing(true)}
          >
            Edit
          </Button>
        )}
      </div>
      
      {/* Profile Content */}
      <div className="container max-w-md mx-auto py-4 px-4">
        {isEditing ? (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <div className="flex justify-center mb-4">
                <div className="relative">
                  <div className="w-24 h-24 bg-neutral-200 rounded-full overflow-hidden">
                    <img 
                      src={user?.profileImage || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde"}
                      alt="Profile" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <button className="absolute right-0 bottom-0 bg-primary text-white p-2 rounded-full">
                    <Camera className="h-4 w-4" />
                  </button>
                </div>
              </div>
              
              <FormField
                control={form.control}
                name="fullName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input {...field} type="email" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="phoneNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone Number</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="pt-4">
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <div className="flex items-center justify-center">
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                      Updating...
                    </div>
                  ) : (
                    "Save Changes"
                  )}
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  className="w-full mt-2"
                  onClick={() => setIsEditing(false)}
                  disabled={isSubmitting}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </Form>
        ) : (
          <>
            {/* Profile Card */}
            <Card className="mb-4">
              <CardContent className="p-4">
                <div className="flex items-center">
                  <div className="w-16 h-16 bg-neutral-200 rounded-full overflow-hidden mr-4">
                    <img 
                      src={user?.profileImage || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde"}
                      alt="Profile" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h2 className="font-semibold text-lg">{user?.fullName}</h2>
                    <div className="flex items-center text-sm text-neutral-500">
                      <Star className="h-4 w-4 text-yellow-400 mr-1" fill="currentColor" />
                      <span>{user?.rating ? user.rating.toFixed(2) : "New"}</span>
                      {user?.ratingCount > 0 && (
                        <span className="ml-1">({user.ratingCount} ratings)</span>
                      )}
                    </div>
                    <p className="text-sm text-neutral-600 mt-1">{user?.isDriver ? "Driver" : "Rider"}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Stats Card */}
            <Card className="mb-4">
              <CardContent className="p-0">
                <div className="grid grid-cols-2 divide-x">
                  <div className="p-4 text-center">
                    <p className="text-sm text-neutral-500">Total Rides</p>
                    <p className="text-xl font-semibold">{totalRides}</p>
                  </div>
                  <div className="p-4 text-center">
                    <p className="text-sm text-neutral-500">Completed</p>
                    <p className="text-xl font-semibold">{completedRides}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Account Info */}
            <Card className="mb-4">
              <CardContent className="p-0">
                <div className="p-3 border-b">
                  <h3 className="font-medium">Account Info</h3>
                </div>
                <div className="divide-y">
                  <div className="flex justify-between items-center p-4">
                    <p className="text-neutral-500">Email</p>
                    <p className="font-medium">{user?.email}</p>
                  </div>
                  <div className="flex justify-between items-center p-4">
                    <p className="text-neutral-500">Phone</p>
                    <p className="font-medium">{user?.phoneNumber}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Payment Methods */}
            {paymentMethods && (
              <Card className="mb-4">
                <CardContent className="p-0">
                  <div className="p-3 border-b">
                    <h3 className="font-medium">Payment</h3>
                  </div>
                  <div className="p-4 flex justify-between items-center">
                    <div className="flex items-center">
                      <div className="bg-neutral-100 p-2 rounded-full mr-3">
                        <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect>
                          <line x1="1" y1="10" x2="23" y2="10"></line>
                        </svg>
                      </div>
                      <div>
                        <p className="font-medium">
                          {defaultPaymentMethod?.type.charAt(0).toUpperCase() + defaultPaymentMethod?.type.slice(1)} 
                          •••• {defaultPaymentMethod?.lastFour}
                        </p>
                        <p className="text-xs text-neutral-500">Default payment method</p>
                      </div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-neutral-400" />
                  </div>
                </CardContent>
              </Card>
            )}
            
            {/* Vehicle Info for drivers */}
            {user?.isDriver && vehicles?.length > 0 && (
              <Card className="mb-4">
                <CardContent className="p-0">
                  <div className="p-3 border-b">
                    <h3 className="font-medium">Vehicle</h3>
                  </div>
                  <div className="divide-y">
                    {vehicles.map(vehicle => (
                      <div key={vehicle.id} className="p-4">
                        <p className="font-medium">{vehicle.year} {vehicle.make} {vehicle.model}</p>
                        <p className="text-sm text-neutral-500">{vehicle.color} • {vehicle.licensePlate}</p>
                        <p className="text-xs mt-1 bg-neutral-100 text-neutral-600 px-2 py-1 rounded-full inline-block">
                          {vehicle.vehicleType.charAt(0).toUpperCase() + vehicle.vehicleType.slice(1)}
                        </p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </>
        )}
      </div>
    </div>
  );
}
