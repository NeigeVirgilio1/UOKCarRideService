import { pgTable, text, serial, integer, boolean, timestamp, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema (represents both riders and drivers)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  fullName: text("full_name").notNull(),
  phoneNumber: text("phone_number").notNull(),
  isDriver: boolean("is_driver").default(false).notNull(),
  profileImage: text("profile_image"),
  rating: doublePrecision("rating").default(0),
  ratingCount: integer("rating_count").default(0),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  rating: true,
  ratingCount: true,
});

// Ride schema
export const rides = pgTable("rides", {
  id: serial("id").primaryKey(),
  riderId: integer("rider_id").notNull(),
  driverId: integer("driver_id"),
  pickupLocation: text("pickup_location").notNull(),
  dropoffLocation: text("dropoff_location").notNull(),
  pickupLatitude: doublePrecision("pickup_latitude").notNull(),
  pickupLongitude: doublePrecision("pickup_longitude").notNull(),
  dropoffLatitude: doublePrecision("dropoff_latitude").notNull(),
  dropoffLongitude: doublePrecision("dropoff_longitude").notNull(),
  status: text("status").notNull(), // requested, accepted, in_progress, completed, cancelled
  rideType: text("ride_type").notNull(), // economy, comfort, premium
  estimatedPrice: doublePrecision("estimated_price").notNull(),
  estimatedDistance: doublePrecision("estimated_distance").notNull(),
  estimatedDuration: integer("estimated_duration").notNull(), // in minutes
  actualPrice: doublePrecision("actual_price"),
  riderRating: integer("rider_rating"),
  driverRating: integer("driver_rating"),
  riderComment: text("rider_comment"),
  driverComment: text("driver_comment"),
  requestedAt: timestamp("requested_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const insertRideSchema = createInsertSchema(rides).omit({
  id: true,
  driverId: true,
  status: true,
  actualPrice: true,
  riderRating: true,
  driverRating: true,
  riderComment: true,
  driverComment: true,
  completedAt: true,
});

// PaymentMethod schema
export const paymentMethods = pgTable("payment_methods", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // credit, debit, paypal, etc.
  lastFour: text("last_four").notNull(),
  expiry: text("expiry"),
  isDefault: boolean("is_default").default(false).notNull(),
});

export const insertPaymentMethodSchema = createInsertSchema(paymentMethods).omit({
  id: true,
});

// Vehicle schema (for drivers)
export const vehicles = pgTable("vehicles", {
  id: serial("id").primaryKey(),
  driverId: integer("driver_id").notNull(),
  make: text("make").notNull(),
  model: text("model").notNull(),
  year: integer("year").notNull(),
  color: text("color").notNull(),
  licensePlate: text("license_plate").notNull(),
  vehicleType: text("vehicle_type").notNull(), // economy, comfort, premium
});

export const insertVehicleSchema = createInsertSchema(vehicles).omit({
  id: true,
});

// Type definitions
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Ride = typeof rides.$inferSelect;
export type InsertRide = z.infer<typeof insertRideSchema>;

export type PaymentMethod = typeof paymentMethods.$inferSelect;
export type InsertPaymentMethod = z.infer<typeof insertPaymentMethodSchema>;

export type Vehicle = typeof vehicles.$inferSelect;
export type InsertVehicle = z.infer<typeof insertVehicleSchema>;

// Ride types and their details
export const RIDE_TYPES = {
  economy: {
    name: "Economy",
    multiplier: 1.0,
    image: "https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
    seats: 4,
  },
  comfort: {
    name: "Comfort",
    multiplier: 1.5,
    image: "https://images.unsplash.com/photo-1546614042-7df3c24c9e5d?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
    seats: 4,
  },
  premium: {
    name: "Premium",
    multiplier: 2.0,
    image: "https://images.unsplash.com/photo-1550355291-bbee04a92027?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
    seats: 4,
  },
};

// Status types for rides
export type RideStatus = "requested" | "accepted" | "in_progress" | "completed" | "cancelled";
