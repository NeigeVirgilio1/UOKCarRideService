import { useState, useEffect } from "react";

interface GeolocationPosition {
  coords: {
    latitude: number;
    longitude: number;
    accuracy: number;
    altitude: number | null;
    altitudeAccuracy: number | null;
    heading: number | null;
    speed: number | null;
  };
  timestamp: number;
}

interface GeolocationError {
  code: number;
  message: string;
}

interface UseGeolocationReturn {
  position: GeolocationPosition | null;
  error: GeolocationError | null;
  getPosition: () => void;
}

export const useGeolocation = (options: PositionOptions = {}): UseGeolocationReturn => {
  const [position, setPosition] = useState<GeolocationPosition | null>(null);
  const [error, setError] = useState<GeolocationError | null>(null);

  const defaultOptions: PositionOptions = {
    enableHighAccuracy: true,
    timeout: 10000,
    maximumAge: 0,
    ...options
  };

  const handleSuccess = (pos: GeolocationPosition) => {
    setPosition(pos);
    setError(null);
  };

  const handleError = (err: GeolocationError) => {
    setError(err);
  };

  const getPosition = () => {
    if (!navigator.geolocation) {
      setError({
        code: 0,
        message: "Geolocation is not supported by this browser."
      });
      return;
    }

    navigator.geolocation.getCurrentPosition(
      handleSuccess,
      handleError,
      defaultOptions
    );
  };

  useEffect(() => {
    let watchId: number;

    if (navigator.geolocation) {
      // Get the initial position
      getPosition();

      // Set up a watch for position changes
      watchId = navigator.geolocation.watchPosition(
        handleSuccess,
        handleError,
        defaultOptions
      );
    } else {
      setError({
        code: 0,
        message: "Geolocation is not supported by this browser."
      });
    }

    // Clean up the watch when component unmounts
    return () => {
      if (navigator.geolocation && watchId) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, []);

  return { position, error, getPosition };
};
