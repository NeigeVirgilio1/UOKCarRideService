import { useEffect, useRef, useState } from "react";
import { useGoogleMaps } from "../hooks/useGoogleMaps";
import MapMarker from "./MapMarker";

interface MapProps {
  pickupLocation?: { lat: number; lng: number } | null;
  dropoffLocation?: { lat: number; lng: number } | null;
  route?: google.maps.DirectionsResult | null;
}

export default function Map({ pickupLocation, dropoffLocation, route }: MapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const [map, setMap] = useState<google.maps.Map | null>(null);
  const [directionsRenderer, setDirectionsRenderer] = useState<google.maps.DirectionsRenderer | null>(null);
  const { isLoaded } = useGoogleMaps();

  // Initialize map
  useEffect(() => {
    if (!isLoaded || !mapRef.current) return;

    const initialLocation = pickupLocation || { lat: 40.7128, lng: -74.0060 }; // Default to NYC

    const mapInstance = new google.maps.Map(mapRef.current, {
      center: initialLocation,
      zoom: 15,
      disableDefaultUI: true,
      zoomControl: true,
      styles: [
        {
          featureType: "poi",
          elementType: "labels",
          stylers: [{ visibility: "off" }]
        }
      ]
    });

    const directionsRendererInstance = new google.maps.DirectionsRenderer({
      map: mapInstance,
      suppressMarkers: true,
      polylineOptions: {
        strokeColor: "#276EF1",
        strokeWeight: 5,
        strokeOpacity: 0.8
      }
    });

    setMap(mapInstance);
    setDirectionsRenderer(directionsRendererInstance);

    return () => {
      // Clean up
    };
  }, [isLoaded]);

  // Update map center when pickup location changes
  useEffect(() => {
    if (!map || !pickupLocation) return;
    map.setCenter(pickupLocation);
  }, [map, pickupLocation]);

  // Update directions when route changes
  useEffect(() => {
    if (!directionsRenderer || !route) return;
    directionsRenderer.setDirections(route);
  }, [directionsRenderer, route]);

  return (
    <div className="h-full w-full bg-neutral-100">
      <div ref={mapRef} className="h-full w-full">
        {!isLoaded && (
          <div className="flex h-full items-center justify-center">
            <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          </div>
        )}
      </div>
      
      {/* Markers */}
      {map && isLoaded && (
        <>
          {pickupLocation && <MapMarker map={map} position={pickupLocation} type="pickup" />}
          {dropoffLocation && <MapMarker map={map} position={dropoffLocation} type="dropoff" />}
        </>
      )}
    </div>
  );
}
