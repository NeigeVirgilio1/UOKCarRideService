import { Switch, Route } from "wouter";
import { useAuth } from "./contexts/AuthContext";
import Home from "./pages/Home";
import Profile from "./pages/Profile";
import RideHistory from "./pages/RideHistory";
import NotFound from "./pages/not-found";
import Auth from "./components/Auth";
import { Suspense, useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import SideMenu from "./components/SideMenu";

function App() {
  const { isAuthenticated, loading } = useAuth();
  const [showSideMenu, setShowSideMenu] = useState(false);
  
  // Check if user is authenticated
  useQuery({
    queryKey: ['/api/auth/me'],
    enabled: !isAuthenticated && !loading,
  });

  // Handle outside click to close side menu
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const sideMenu = document.getElementById('side-menu');
      const menuButton = document.getElementById('menu-button');
      
      if (showSideMenu && sideMenu && !sideMenu.contains(e.target as Node) && menuButton && !menuButton.contains(e.target as Node)) {
        setShowSideMenu(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showSideMenu]);

  if (loading) {
    return (
      <div className="h-screen w-full flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <>
      {!isAuthenticated ? (
        <Auth />
      ) : (
        <>
          <SideMenu isOpen={showSideMenu} onClose={() => setShowSideMenu(false)} />
          
          <Suspense fallback={<div>Loading...</div>}>
            <Switch>
              <Route path="/" component={() => <Home onMenuClick={() => setShowSideMenu(true)} />} />
              <Route path="/profile" component={Profile} />
              <Route path="/history" component={RideHistory} />
              <Route component={NotFound} />
            </Switch>
          </Suspense>
        </>
      )}
    </>
  );
}

export default App;
