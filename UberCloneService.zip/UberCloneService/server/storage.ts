import { 
  users, User, InsertUser, 
  rides, Ride, InsertRide,
  paymentMethods, PaymentMethod, InsertPaymentMethod,
  vehicles, Vehicle, InsertVehicle,
  RideStatus
} from "@shared/schema";

// Storage interface for all operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // Ride operations
  getRide(id: number): Promise<Ride | undefined>;
  getUserRides(userId: number): Promise<Ride[]>;
  getDriverRides(driverId: number): Promise<Ride[]>;
  createRide(ride: InsertRide): Promise<Ride>;
  updateRide(id: number, ride: Partial<Ride>): Promise<Ride | undefined>;
  getActiveRidesByUser(userId: number): Promise<Ride[]>;
  getNearbyRideRequests(latitude: number, longitude: number, maxDistance: number): Promise<Ride[]>;
  
  // Payment method operations
  getUserPaymentMethods(userId: number): Promise<PaymentMethod[]>;
  getDefaultPaymentMethod(userId: number): Promise<PaymentMethod | undefined>;
  createPaymentMethod(paymentMethod: InsertPaymentMethod): Promise<PaymentMethod>;
  
  // Vehicle operations
  getDriverVehicles(driverId: number): Promise<Vehicle[]>;
  createVehicle(vehicle: InsertVehicle): Promise<Vehicle>;
}

// In-memory implementation of the storage interface
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private rides: Map<number, Ride>;
  private paymentMethods: Map<number, PaymentMethod>;
  private vehicles: Map<number, Vehicle>;
  
  private userId: number;
  private rideId: number;
  private paymentMethodId: number;
  private vehicleId: number;
  
  constructor() {
    this.users = new Map();
    this.rides = new Map();
    this.paymentMethods = new Map();
    this.vehicles = new Map();
    
    this.userId = 1;
    this.rideId = 1;
    this.paymentMethodId = 1;
    this.vehicleId = 1;
    
    this.seedData();
  }
  
  // Initialize with sample data
  private seedData() {
    // Create a rider
    const rider: InsertUser = {
      username: "rider",
      password: "password",
      email: "rider@example.com",
      fullName: "Sarah Davis",
      phoneNumber: "+1 (555) 123-4567",
      isDriver: false,
      profileImage: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80"
    };
    const riderUser = this.createUser(rider);
    
    // Create a driver
    const driver: InsertUser = {
      username: "driver",
      password: "password",
      email: "driver@example.com",
      fullName: "Michael Johnson",
      phoneNumber: "+1 (555) 987-6543",
      isDriver: true,
      profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80"
    };
    const driverUser = this.createUser(driver);
    
    // Create payment method
    const paymentMethod: InsertPaymentMethod = {
      userId: 1,
      type: "visa",
      lastFour: "4242",
      expiry: "12/24",
      isDefault: true
    };
    this.createPaymentMethod(paymentMethod);
    
    // Create vehicle for driver
    const vehicle: InsertVehicle = {
      driverId: 2,
      make: "Tesla",
      model: "Model 3",
      year: 2022,
      color: "White",
      licensePlate: "ABC 123",
      vehicleType: "premium"
    };
    this.createVehicle(vehicle);
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id, rating: 0, ratingCount: 0 };
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, update: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...update };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // Ride operations
  async getRide(id: number): Promise<Ride | undefined> {
    return this.rides.get(id);
  }
  
  async getUserRides(userId: number): Promise<Ride[]> {
    return Array.from(this.rides.values()).filter(ride => ride.riderId === userId);
  }
  
  async getDriverRides(driverId: number): Promise<Ride[]> {
    return Array.from(this.rides.values()).filter(ride => ride.driverId === driverId);
  }
  
  async createRide(insertRide: InsertRide): Promise<Ride> {
    const id = this.rideId++;
    const ride: Ride = { 
      ...insertRide, 
      id, 
      driverId: null, 
      status: "requested", 
      actualPrice: null,
      riderRating: null,
      driverRating: null,
      riderComment: null,
      driverComment: null,
      completedAt: null
    };
    this.rides.set(id, ride);
    return ride;
  }
  
  async updateRide(id: number, update: Partial<Ride>): Promise<Ride | undefined> {
    const ride = this.rides.get(id);
    if (!ride) return undefined;
    
    const updatedRide = { ...ride, ...update };
    this.rides.set(id, updatedRide);
    return updatedRide;
  }
  
  async getActiveRidesByUser(userId: number): Promise<Ride[]> {
    const activeStatuses: RideStatus[] = ["requested", "accepted", "in_progress"];
    return Array.from(this.rides.values()).filter(ride => 
      ride.riderId === userId && activeStatuses.includes(ride.status as RideStatus)
    );
  }
  
  async getNearbyRideRequests(latitude: number, longitude: number, maxDistance: number): Promise<Ride[]> {
    // In a real app, we'd do a proper geospatial query
    // For this demo, just return all requested rides
    return Array.from(this.rides.values()).filter(ride => ride.status === "requested" && !ride.driverId);
  }
  
  // Payment method operations
  async getUserPaymentMethods(userId: number): Promise<PaymentMethod[]> {
    return Array.from(this.paymentMethods.values()).filter(pm => pm.userId === userId);
  }
  
  async getDefaultPaymentMethod(userId: number): Promise<PaymentMethod | undefined> {
    return Array.from(this.paymentMethods.values()).find(pm => pm.userId === userId && pm.isDefault);
  }
  
  async createPaymentMethod(insertPaymentMethod: InsertPaymentMethod): Promise<PaymentMethod> {
    const id = this.paymentMethodId++;
    const paymentMethod: PaymentMethod = { ...insertPaymentMethod, id };
    this.paymentMethods.set(id, paymentMethod);
    
    // If this is the default payment method, update other payment methods
    if (paymentMethod.isDefault) {
      for (const [otherPmId, otherPm] of this.paymentMethods.entries()) {
        if (otherPm.userId === paymentMethod.userId && otherPm.id !== paymentMethod.id && otherPm.isDefault) {
          this.paymentMethods.set(otherPmId, { ...otherPm, isDefault: false });
        }
      }
    }
    
    return paymentMethod;
  }
  
  // Vehicle operations
  async getDriverVehicles(driverId: number): Promise<Vehicle[]> {
    return Array.from(this.vehicles.values()).filter(vehicle => vehicle.driverId === driverId);
  }
  
  async createVehicle(insertVehicle: InsertVehicle): Promise<Vehicle> {
    const id = this.vehicleId++;
    const vehicle: Vehicle = { ...insertVehicle, id };
    this.vehicles.set(id, vehicle);
    return vehicle;
  }
}

export const storage = new MemStorage();
