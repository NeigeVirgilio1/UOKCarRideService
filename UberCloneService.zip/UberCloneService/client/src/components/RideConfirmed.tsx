import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { MessageSquare, Phone, Share2 } from "lucide-react";

interface RideConfirmedProps {
  rideId: number;
  onCancel: () => void;
  onComplete: () => void;
}

export default function RideConfirmed({ rideId, onCancel, onComplete }: RideConfirmedProps) {
  const { toast } = useToast();
  const [isCancelling, setIsCancelling] = useState(false);
  
  // Get ride details
  const { data: ride, isLoading } = useQuery({
    queryKey: [`/api/rides/${rideId}`],
    refetchInterval: 5000, // Poll for updates
  });
  
  // Get driver details if available
  const { data: driver } = useQuery({
    queryKey: [`/api/users/${ride?.driverId}`],
    enabled: !!ride?.driverId,
  });
  
  const handleCancelRide = async () => {
    setIsCancelling(true);
    try {
      await apiRequest("PATCH", `/api/rides/${rideId}`, { status: "cancelled" });
      queryClient.invalidateQueries({ queryKey: ['/api/rides'] });
      toast({
        title: "Ride cancelled",
        description: "Your ride has been cancelled",
      });
      onCancel();
    } catch (error) {
      toast({
        title: "Error cancelling ride",
        description: error instanceof Error ? error.message : "Something went wrong",
        variant: "destructive",
      });
    } finally {
      setIsCancelling(false);
    }
  };
  
  // Check if ride is completed (for demo purposes)
  if (ride?.status === "completed") {
    setTimeout(() => {
      onComplete();
    }, 1000);
  }
  
  if (isLoading) {
    return (
      <div className="absolute bottom-0 left-0 right-0 bg-white rounded-t-2xl shadow-2xl z-20 p-4">
        <div className="flex justify-center items-center h-32">
          <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        </div>
      </div>
    );
  }
  
  if (!ride) {
    return null;
  }
  
  const eta = "3 min"; // Simplified; would come from ride data
  
  return (
    <div className="absolute bottom-0 left-0 right-0 bg-white rounded-t-2xl shadow-2xl z-20 p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold">Your ride is on the way</h2>
        <span className="bg-primary/10 text-primary px-2 py-1 rounded text-sm font-medium">{eta}</span>
      </div>
      
      <div className="flex items-center p-4 bg-neutral-100 rounded-lg mb-4">
        <div className="w-14 h-14 bg-neutral-200 rounded-full overflow-hidden mr-4">
          <img 
            src={driver?.profileImage || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d"}
            alt="Driver" 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="flex-1">
          <div className="flex justify-between items-center mb-1">
            <h3 className="font-medium">{driver?.fullName || "Driver"}</h3>
            <div className="flex items-center">
              <svg className="w-4 h-4 text-yellow-400 fill-current mr-1" viewBox="0 0 20 20">
                <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
              </svg>
              <span>{driver?.rating?.toFixed(2) || "4.89"}</span>
            </div>
          </div>
          <p className="text-sm text-neutral-500">Tesla Model 3 • ABC 123</p>
        </div>
      </div>
      
      <div className="grid grid-cols-3 gap-2 mb-4">
        <Button variant="outline" className="flex flex-col items-center justify-center bg-neutral-100 p-3 rounded-lg h-auto">
          <MessageSquare className="h-5 w-5 mb-1" />
          <span className="text-xs">Message</span>
        </Button>
        <Button variant="outline" className="flex flex-col items-center justify-center bg-neutral-100 p-3 rounded-lg h-auto">
          <Phone className="h-5 w-5 mb-1" />
          <span className="text-xs">Call</span>
        </Button>
        <Button variant="outline" className="flex flex-col items-center justify-center bg-neutral-100 p-3 rounded-lg h-auto">
          <Share2 className="h-5 w-5 mb-1" />
          <span className="text-xs">Share ETA</span>
        </Button>
      </div>
      
      <Button 
        variant="outline" 
        className="w-full border border-red-500 text-red-500 font-medium py-3 rounded-lg"
        onClick={handleCancelRide}
        disabled={isCancelling}
      >
        {isCancelling ? (
          <div className="flex items-center justify-center">
            <div className="w-5 h-5 border-2 border-red-500 border-t-transparent rounded-full animate-spin mr-2"></div>
            Cancelling...
          </div>
        ) : (
          "Cancel ride"
        )}
      </Button>
    </div>
  );
}
