import { useEffect, useState } from "react";

interface MapMarkerProps {
  map: google.maps.Map;
  position: { lat: number; lng: number };
  type: "pickup" | "dropoff";
}

export default function MapMarker({ map, position, type }: MapMarkerProps) {
  const [marker, setMarker] = useState<google.maps.Marker | null>(null);

  useEffect(() => {
    // Create custom marker icon
    const svgIcon = {
      url: createSvgMarker(type === "pickup" ? "#276EF1" : "#06C167"),
      scaledSize: new google.maps.Size(30, 30),
      anchor: new google.maps.Point(15, 15),
    };

    // Create marker
    const markerInstance = new google.maps.Marker({
      position,
      map,
      icon: svgIcon,
      animation: google.maps.Animation.DROP,
      title: type === "pickup" ? "Pickup location" : "Dropoff location",
    });

    setMarker(markerInstance);

    // Add pulse effect for pickup location
    if (type === "pickup") {
      const pulse = createPulseEffect(position, map);
      setTimeout(() => pulse.setMap(null), 5000); // Remove after 5 seconds
    }

    return () => {
      if (markerInstance) {
        markerInstance.setMap(null);
      }
    };
  }, [map, position, type]);

  // Helper to create SVG marker
  function createSvgMarker(fillColor: string): string {
    const svg = `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="30" height="30">
        <circle cx="12" cy="12" r="10" fill="${fillColor}" />
        <circle cx="12" cy="12" r="6" fill="white" />
      </svg>
    `;
    return 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(svg);
  }

  // Helper to create pulse effect
  function createPulseEffect(position: { lat: number; lng: number }, map: google.maps.Map): google.maps.Circle {
    return new google.maps.Circle({
      strokeColor: "#276EF1",
      strokeOpacity: 0.5,
      strokeWeight: 2,
      fillColor: "#276EF1",
      fillOpacity: 0.2,
      map,
      center: position,
      radius: 100,
      animation: google.maps.Animation.BOUNCE,
    });
  }

  return null; // Marker is created imperatively
}
