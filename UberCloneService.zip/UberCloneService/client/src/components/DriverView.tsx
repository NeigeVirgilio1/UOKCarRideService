import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useAuth } from "../contexts/AuthContext";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Bell, Menu } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface DriverViewProps {
  onMenuClick: () => void;
}

export default function DriverView({ onMenuClick }: DriverViewProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isOnline, setIsOnline] = useState(true);
  const [activeRideId, setActiveRideId] = useState<number | null>(null);
  const [rideRequestId, setRideRequestId] = useState<number | null>(null);
  const [rideStatus, setRideStatus] = useState<string | null>(null);
  const [countdown, setCountdown] = useState(15);
  
  // Get active rides
  const { data: activeRides } = useQuery({
    queryKey: ['/api/rides/active'],
    refetchInterval: 5000,
  });
  
  // Get nearby ride requests
  const { data: nearbyRequests } = useQuery({
    queryKey: ['/api/driver/requests'],
    refetchInterval: isOnline ? 5000 : false,
    enabled: isOnline && !activeRideId && !rideRequestId,
  });
  
  // Get active ride details
  const { data: activeRide } = useQuery({
    queryKey: [`/api/rides/${activeRideId}`],
    enabled: !!activeRideId,
    refetchInterval: 5000,
  });
  
  // Get rider info
  const { data: rider } = useQuery({
    queryKey: [`/api/users/${activeRide?.riderId}`],
    enabled: !!activeRide?.riderId,
  });
  
  // Handle ride request arrival
  useEffect(() => {
    if (isOnline && nearbyRequests?.length && !rideRequestId && !activeRideId) {
      // Show the first ride request
      setRideRequestId(nearbyRequests[0].id);
      setCountdown(15);
    }
  }, [nearbyRequests, isOnline, rideRequestId, activeRideId]);
  
  // Countdown timer for ride request
  useEffect(() => {
    if (rideRequestId && countdown > 0) {
      const timer = setTimeout(() => {
        setCountdown(countdown - 1);
      }, 1000);
      
      return () => clearTimeout(timer);
    } else if (rideRequestId && countdown === 0) {
      // Auto decline after countdown
      handleDeclineRide();
    }
  }, [rideRequestId, countdown]);
  
  // Check for existing active ride on component mount
  useEffect(() => {
    if (activeRides?.length) {
      const ride = activeRides[0];
      setActiveRideId(ride.id);
      setRideStatus(ride.status);
    }
  }, [activeRides]);
  
  const handleAcceptRide = async () => {
    if (!rideRequestId) return;
    
    try {
      await apiRequest("PATCH", `/api/rides/${rideRequestId}`, {
        status: "accepted"
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/rides/active'] });
      toast({
        title: "Ride accepted",
        description: "You've accepted the ride request",
      });
      
      setActiveRideId(rideRequestId);
      setRideRequestId(null);
      setRideStatus("accepted");
    } catch (error) {
      toast({
        title: "Error accepting ride",
        description: error instanceof Error ? error.message : "Something went wrong",
        variant: "destructive",
      });
    }
  };
  
  const handleDeclineRide = () => {
    setRideRequestId(null);
    setCountdown(15);
  };
  
  const handleStartRide = async () => {
    if (!activeRideId) return;
    
    try {
      await apiRequest("PATCH", `/api/rides/${activeRideId}`, {
        status: "in_progress"
      });
      
      queryClient.invalidateQueries({ queryKey: [`/api/rides/${activeRideId}`] });
      toast({
        title: "Ride started",
        description: "You've started the ride",
      });
      
      setRideStatus("in_progress");
    } catch (error) {
      toast({
        title: "Error starting ride",
        description: error instanceof Error ? error.message : "Something went wrong",
        variant: "destructive",
      });
    }
  };
  
  const handleCompleteRide = async () => {
    if (!activeRideId) return;
    
    try {
      await apiRequest("PATCH", `/api/rides/${activeRideId}`, {
        status: "completed"
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/rides/active'] });
      toast({
        title: "Ride completed",
        description: "You've completed the ride",
      });
      
      setActiveRideId(null);
      setRideStatus(null);
    } catch (error) {
      toast({
        title: "Error completing ride",
        description: error instanceof Error ? error.message : "Something went wrong",
        variant: "destructive",
      });
    }
  };
  
  const toggleOnlineStatus = () => {
    setIsOnline(!isOnline);
  };
  
  // Mocked earnings data
  const earnings = {
    today: 154.25,
    trips: 7,
    hours: 5.2,
    goal: 200
  };
  
  return (
    <div id="driver-view" className="h-full">
      {/* Driver Header */}
      <div className="absolute top-0 left-0 right-0 z-10 bg-primary text-white px-4 py-3 flex items-center justify-between">
        <div className="flex items-center">
          <Button 
            variant="ghost" 
            size="icon" 
            className="text-white mr-3 hover:bg-primary-foreground/10"
            onClick={onMenuClick}
          >
            <Menu className="h-5 w-5" />
          </Button>
          <div>
            <h3 className="font-medium">{user?.fullName || "Driver"}</h3>
            <div className="flex items-center text-sm">
              <svg className="w-4 h-4 text-yellow-400 fill-current mr-1" viewBox="0 0 20 20">
                <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
              </svg>
              <span>{user?.rating?.toFixed(2) || "4.89"}</span>
            </div>
          </div>
        </div>
        <div className="flex items-center">
          <Button 
            variant="ghost" 
            size="sm" 
            className={`${isOnline ? 'bg-green-500/20' : 'bg-red-500/20'} text-white px-2 py-1 rounded text-sm font-medium mr-2 hover:bg-opacity-30`}
            onClick={toggleOnlineStatus}
          >
            {isOnline ? "Online" : "Offline"}
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="bg-white/20 p-2 rounded-full hover:bg-white/30"
          >
            <Bell className="h-5 w-5" />
          </Button>
        </div>
      </div>
      
      {/* Driver Status Card */}
      <div className="absolute top-16 left-4 right-4 z-10">
        <div className="bg-white rounded-lg shadow-lg p-4">
          <div className="flex justify-between items-center mb-3">
            <h3 className="font-medium">Today's earnings</h3>
            <span className="text-lg font-semibold">${earnings.today.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-sm text-neutral-500 mb-4">
            <span>{earnings.trips} trips</span>
            <span>{earnings.hours} hours online</span>
          </div>
          <div className="h-2 bg-neutral-200 rounded-full overflow-hidden mb-3">
            <div 
              className="h-full bg-green-500" 
              style={{ width: `${(earnings.today / earnings.goal) * 100}%` }}
            ></div>
          </div>
          <p className="text-xs text-neutral-500 text-center">
            ${(earnings.goal - earnings.today).toFixed(2)} more to reach your ${earnings.goal} goal
          </p>
        </div>
      </div>
      
      {/* New Ride Request */}
      {rideRequestId && nearbyRequests && (
        <div className="absolute bottom-0 left-0 right-0 bg-white rounded-t-2xl shadow-2xl z-20 p-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">New ride request</h2>
            <div className="flex items-center">
              <span className="text-neutral-500 mr-1">{countdown}s</span>
              <div className="w-10 h-10 rounded-full border-2 border-r-transparent border-primary animate-spin"></div>
            </div>
          </div>
          
          {nearbyRequests.map(request => {
            if (request.id === rideRequestId) {
              return (
                <div key={request.id} className="mb-4">
                  <div className="flex items-center mb-3">
                    <div className="flex flex-col items-center mr-3">
                      <div className="w-3 h-3 rounded-full bg-primary"></div>
                      <div className="w-0.5 h-10 bg-neutral-300 my-1"></div>
                      <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    </div>
                    <div className="flex-1 space-y-2">
                      <div>
                        <p className="font-medium">Pickup location</p>
                        <p className="text-sm text-neutral-500">{request.pickupLocation}</p>
                      </div>
                      <div>
                        <p className="font-medium">Dropoff location</p>
                        <p className="text-sm text-neutral-500">{request.dropoffLocation}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center mb-4 bg-neutral-100 p-3 rounded-lg">
                    <div>
                      <p className="text-sm text-neutral-500">Estimated fare</p>
                      <p className="font-semibold">${request.estimatedPrice.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-neutral-500">Distance</p>
                      <p className="font-semibold">{(request.estimatedDistance).toFixed(1)} mi</p>
                    </div>
                    <div>
                      <p className="text-sm text-neutral-500">Est. time</p>
                      <p className="font-semibold">{request.estimatedDuration} min</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <Button 
                      variant="outline"
                      className="py-3 rounded-lg border border-neutral-300 font-medium"
                      onClick={handleDeclineRide}
                    >
                      Decline
                    </Button>
                    <Button 
                      className="py-3 rounded-lg bg-primary text-white font-medium"
                      onClick={handleAcceptRide}
                    >
                      Accept
                    </Button>
                  </div>
                </div>
              );
            }
            return null;
          })}
        </div>
      )}
      
      {/* Active Ride */}
      {activeRideId && activeRide && (
        <div className="absolute bottom-0 left-0 right-0 bg-white rounded-t-2xl shadow-2xl z-20 p-4">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h2 className="text-lg font-semibold">
                {rideStatus === "accepted" 
                  ? "En route to pickup" 
                  : rideStatus === "in_progress" 
                    ? "Trip in progress" 
                    : "Arrived at pickup"}
              </h2>
              <p className="text-sm text-neutral-500">
                {rideStatus === "accepted" 
                  ? "2 min away" 
                  : rideStatus === "in_progress" 
                    ? `${Math.round(activeRide.estimatedDuration)} min remaining` 
                    : "Waiting for rider"}
              </p>
            </div>
            <Button variant="outline" size="icon" className="bg-neutral-100 p-2 rounded-full">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="1"></circle>
                <circle cx="19" cy="12" r="1"></circle>
                <circle cx="5" cy="12" r="1"></circle>
              </svg>
            </Button>
          </div>
          
          <div className="flex items-center p-4 bg-neutral-100 rounded-lg mb-4">
            <div className="w-14 h-14 bg-neutral-200 rounded-full overflow-hidden mr-4">
              <img 
                src={rider?.profileImage || "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2"}
                alt="Passenger" 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex-1">
              <div className="flex justify-between items-center mb-1">
                <h3 className="font-medium">{rider?.fullName || "Rider"}</h3>
                <div className="flex items-center">
                  <svg className="w-4 h-4 text-yellow-400 fill-current mr-1" viewBox="0 0 20 20">
                    <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                  </svg>
                  <span>{rider?.rating?.toFixed(2) || "4.92"}</span>
                </div>
              </div>
              <p className="text-sm text-neutral-500">
                {activeRide.rideType.charAt(0).toUpperCase() + activeRide.rideType.slice(1)} • 
                ${activeRide.estimatedPrice.toFixed(2)}
              </p>
            </div>
          </div>
          
          <div className="mb-4">
            <div className="flex items-center mb-3">
              <div className="flex flex-col items-center mr-3">
                <div className="w-3 h-3 rounded-full bg-primary"></div>
                <div className="w-0.5 h-10 bg-neutral-300 my-1"></div>
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
              </div>
              <div className="flex-1 space-y-2">
                <div>
                  <p className="font-medium">Pickup location</p>
                  <p className="text-sm text-neutral-500">{activeRide.pickupLocation}</p>
                </div>
                <div>
                  <p className="font-medium">Dropoff location</p>
                  <p className="text-sm text-neutral-500">{activeRide.dropoffLocation}</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-2 mb-4">
            <Button 
              variant="outline"
              className="flex flex-col items-center justify-center bg-neutral-100 p-3 rounded-lg h-auto"
            >
              <svg className="h-5 w-5 mb-1" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
              </svg>
              <span className="text-xs">Message</span>
            </Button>
            <Button 
              variant="outline"
              className="flex flex-col items-center justify-center bg-neutral-100 p-3 rounded-lg h-auto"
            >
              <svg className="h-5 w-5 mb-1" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
              </svg>
              <span className="text-xs">Call</span>
            </Button>
            <Button 
              variant="outline"
              className="flex flex-col items-center justify-center bg-neutral-100 p-3 rounded-lg h-auto"
            >
              <svg className="h-5 w-5 mb-1" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="3 11 22 2 13 21 11 13 3 11"></polygon>
              </svg>
              <span className="text-xs">Navigate</span>
            </Button>
          </div>
          
          <Button 
            className="w-full bg-primary text-white font-medium py-3 rounded-lg"
            onClick={rideStatus === "accepted" ? handleStartRide : handleCompleteRide}
          >
            {rideStatus === "accepted" 
              ? "Arrived at pickup" 
              : rideStatus === "in_progress" 
                ? "Complete trip" 
                : "Start trip"}
          </Button>
        </div>
      )}
    </div>
  );
}
